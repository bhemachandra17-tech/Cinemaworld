# CinemaWorld

A responsive, static movie-discovery website.

## Files

- `index.html` — page structure
- `styles.css` — responsive styling
- `script.js` — search, filters, movie catalog and viewing links

## Run locally

Open `index.html` in a browser.

## Publish

Upload the three files to any static web host, such as GitHub Pages, Cloudflare Pages, Netlify, or another provider.

## Important

Only add viewing links that you are authorized to distribute or link to. This starter site does not host movie files. The Telugu entries marked "Authorized source" are placeholders; replace their `url` values with verified official/licensed viewing pages before publishing.

## Add a movie

In `script.js`, add an object:

{
  title: "Movie title",
  year: 2025,
  language: "Telugu",
  genre: "Drama",
  source: "Official source",
  url: "https://example.com/official-video"
}
