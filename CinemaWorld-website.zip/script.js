const movies = [
  {title:"His Girl Friday",year:1940,language:"English",genre:"Comedy",source:"Internet Archive",url:"https://archive.org/"},
  {title:"The General",year:1926,language:"English",genre:"Action",source:"Internet Archive",url:"https://archive.org/"},
  {title:"Sherlock Jr.",year:1924,language:"English",genre:"Comedy",source:"Internet Archive",url:"https://archive.org/"},
  {title:"The Kid",year:1921,language:"English",genre:"Comedy",source:"Internet Archive",url:"https://archive.org/"},
  {title:"A Trip to the Moon",year:1902,language:"French",genre:"Sci-Fi",source:"Internet Archive",url:"https://archive.org/"},
  {title:"The Cabinet of Dr. Caligari",year:1920,language:"German",genre:"Drama",source:"Internet Archive",url:"https://archive.org/"},
  {title:"Nosferatu",year:1922,language:"German",genre:"Drama",source:"Internet Archive",url:"https://archive.org/"},
  {title:"Metropolis",year:1927,language:"German",genre:"Sci-Fi",source:"Internet Archive",url:"https://archive.org/"},
  {title:"Mayabazar",year:1957,language:"Telugu",genre:"Fantasy",source:"Authorized source",url:"#"},
  {title:"Missamma",year:1955,language:"Telugu",genre:"Comedy",source:"Authorized source",url:"#"},
  {title:"Pathala Bhairavi",year:1951,language:"Telugu",genre:"Fantasy",source:"Authorized source",url:"#"},
  {title:"Devadasu",year:1953,language:"Telugu",genre:"Drama",source:"Authorized source",url:"#"},
  {title:"Malliswari",year:1951,language:"Telugu",genre:"Drama",source:"Authorized source",url:"#"}
];

const languageLabels = {
  All:"All", English:"English", Telugu:"తెలుగు", Hindi:"हिन्दी", Tamil:"தமிழ்",
  Malayalam:"മലയാളം", Kannada:"ಕನ್ನಡ", Bengali:"বাংলা", French:"Français",
  German:"Deutsch", Spanish:"Español", Japanese:"日本語", Korean:"한국어"
};

let selectedLanguage = "All";
const grid = document.getElementById("movieGrid");
const search = document.getElementById("search");
const genre = document.getElementById("genre");
const filters = document.getElementById("languageFilters");

const languages = ["All", ...new Set(movies.map(m => m.language))];
filters.innerHTML = languages.map(l =>
  `<button class="chip ${l==="All"?"active":""}" data-language="${l}">${languageLabels[l] || l}</button>`
).join("");

filters.addEventListener("click", e => {
  const btn = e.target.closest(".chip");
  if(!btn) return;
  selectedLanguage = btn.dataset.language;
  document.querySelectorAll(".chip").forEach(x => x.classList.remove("active"));
  btn.classList.add("active");
  render();
});

function render(){
  const q = search.value.trim().toLowerCase();
  const g = genre.value;
  const list = movies.filter(m =>
    (selectedLanguage==="All" || m.language===selectedLanguage) &&
    (g==="all" || m.genre===g) &&
    (!q || `${m.title} ${m.language} ${m.genre}`.toLowerCase().includes(q))
  );

  document.getElementById("resultCount").textContent =
    `${list.length} movie${list.length===1?"":"s"}`;

  grid.innerHTML = list.length ? list.map((m,i) => `
    <article class="card">
      <div class="poster"><div class="poster-title">${escapeHtml(m.title)}</div></div>
      <div class="info">
        <strong>${escapeHtml(m.title)}</strong>
        <div class="meta">${m.year} · ${escapeHtml(m.language)} · ${escapeHtml(m.genre)}</div>
        <button class="watch" data-index="${i}">Watch legally</button>
      </div>
    </article>
  `).join("") : `<div class="empty">No matching movies found.</div>`;

  grid.querySelectorAll(".watch").forEach(btn => {
    btn.addEventListener("click", () => {
      const m = list[Number(btn.dataset.index)];
      if(m.url === "#"){
        alert("This listing is a placeholder. Add an official/licensed viewing URL to script.js before publishing.");
      } else {
        window.open(m.url,"_blank","noopener,noreferrer");
      }
    });
  });
}

function escapeHtml(s){
  return s.replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}
search.addEventListener("input",render);
genre.addEventListener("change",render);
document.getElementById("year").textContent = new Date().getFullYear();
render();
